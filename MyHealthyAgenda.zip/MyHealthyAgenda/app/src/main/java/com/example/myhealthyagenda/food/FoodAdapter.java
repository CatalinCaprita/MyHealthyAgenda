package com.example.myhealthyagenda.food;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myhealthyagenda.R;
import com.example.myhealthyagenda.pages.diary.DiaryActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.ViewHolder> {

    private Map<Integer,Integer> foodIndexes;
    private ArrayList<Food> foods;
    private OnFoodClickListener onFoodClickListener;
    private Activity context;
    private final int mealId;
    private static final String TAG = "FoodAdapter::";

    public FoodAdapter(Context context, Map<Integer,Food> foods,int mealId){
        this.foods = new ArrayList<>(foods.values());
        this.foodIndexes = new HashMap<>();
        for(int i=0 ; i < this.foods.size(); i++){
                foodIndexes.put(this.foods.get(i).ID,i);
        }
        this.mealId = mealId;
        try{
            this.onFoodClickListener = (OnFoodClickListener)context;
            this.context = (Activity)context;
        }catch(ClassCastException e){
            Log.e("ERROR",e.toString());
        }
    }

    @NonNull
    @Override
    public FoodAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_food,parent,false);
        return new FoodAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Log.d(TAG + "onBindViewHolder","Binding a viewHolder to position " + position);
        Food food = foods.get(position);
        holder.itemView.setTag(food);
        holder.tvTotalKcal.setText(String.format("%4.2f",food.getTotalKCal()));
        holder.tvSourceQuantity.setText(context.getString(R.string.label_food_source_quant,food.getSource(),food.getQuantityGrams()));
        holder.tvFoodName.setText(food.getName());
        /*
        TO DO
         */
        //((DiaryActivity)context).getSupportFragmentManager().
    }

    @Override
    public int getItemCount() {
        return foods.size();
    }

    public void addFood(Food food){
        this.foods.add(food);
        foodIndexes.put(food.ID,foods.size() - 1);
        notifyItemInserted(foods.size() - 1);
    }
    public void updateDataSet(Map<Integer,Food> newFoods){
        this.foods = new ArrayList<>(newFoods.values());
        for(int i=0 ; i < this.foods.size(); i++){
            foodIndexes.put(this.foods.get(i).ID,i);
        }
        notifyDataSetChanged();
        Log.d(TAG+"onUpdateDataSet","current MealId " + mealId);
    }

    public void updateSingleItem(int foodId){
        Log.d("FOODADAPTER","Updating the food Item quantity. Preying it workds");
        Log.d("FoodAdapter::updateSingleItem","After :" + foods.get(foodIndexes.get(foodId)));
        notifyItemChanged(foodIndexes.get(foodId));
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvFoodName, tvSourceQuantity,tvTotalKcal;
        public ViewHolder(View itemView){
            super(itemView);
            tvFoodName = itemView.findViewById(R.id.tvName);
            tvSourceQuantity = itemView.findViewById(R.id.tvProviderQuantiy);
            tvTotalKcal = itemView.findViewById(R.id.tvTotalKcal);

            itemView.setOnClickListener(view ->{
                try{
                    Log.d(TAG+"onClickListener","current MealId " + mealId);
                    onFoodClickListener.onFoodClick((Food)itemView.getTag(),mealId);

                }catch(ClassCastException e){
                    e.printStackTrace();
                    Log.e("ERROR","COULD NOT CAST tag to Food item");
                }
            });
        }
    }

    /*
     TODO: UPDATE ITEM SO THAT YOU START FRAGMENT FROM FOODADAPTER
     */
    public interface OnFoodClickListener{
        void onFoodClick(Food food, int mealId);
    }
}
