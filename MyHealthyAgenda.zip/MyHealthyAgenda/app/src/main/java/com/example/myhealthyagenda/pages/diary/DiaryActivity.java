package com.example.myhealthyagenda.pages.diary;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.example.myhealthyagenda.ApplicationClass;
import com.example.myhealthyagenda.BaseMenuActivity;
import com.example.myhealthyagenda.R;
import com.example.myhealthyagenda.food.Food;
import com.example.myhealthyagenda.food.FoodAdapter;
import com.example.myhealthyagenda.food.Meal;
import com.example.myhealthyagenda.food.MealAdapter;
import com.example.myhealthyagenda.fragments.BalanceFragment;
import com.example.myhealthyagenda.menu.MenuItem;
import com.example.myhealthyagenda.pages.diary.fragments.AddFoodDialogFragment;
import com.example.myhealthyagenda.pages.diary.fragments.DialogEditFoodFragment;
import com.example.myhealthyagenda.pages.diary.fragments.FoodDetailFragment;
import com.example.myhealthyagenda.util.Serializer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class DiaryActivity extends BaseMenuActivity implements com.example.myhealthyagenda.menu.MenuFragment.onItemClickedListener,
        FoodAdapter.OnFoodClickListener,
        FoodDetailFragment.OnFoodEditedListener ,
        MealAdapter.OnAddFoodFragmentInitListener,
        AddFoodDialogFragment.OnFoodAddedListener{

    ArrayList<Meal> meals = new ArrayList<>();
    BalanceFragment fragBalance;
    FrameLayout frameBalance,frameFoodDetail;
    RecyclerView rvMeals;
    ActionBar actionBar;
    FragmentManager manager;
    private static final String TAG = "DiaryActivity::";
    public static final String FRAGMENT_BALANCE = "FRAG_BALANCE";
    public static final String FRAGMENT_FOOD_DETAIL = "FRAG_FOOD_DETAIL";
    public static final String FRAGMENT_ADD_FOOD = "FRAG_FOOD_ADD";

    public static final int MENU_EDIT  = 0;
    public static final int MENU_NUTRITION = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary);
        Random r = new Random(System.currentTimeMillis());
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar_diary));
        actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setTitle(R.string.title_diary);
        actionBar.show();
        frameFoodDetail = findViewById(R.id.frame_food_detail_frag);
        manager = getSupportFragmentManager();
        manager.beginTransaction()
                .replace(R.id.frame_balance,BalanceFragment.newInstance(user.getTotalKcal(),
                        user.getActualKcal()),BalanceFragment.TAG_FRAG_BALANCE)
                .commit();

        try{
            meals = Serializer.getInstance().deserialize((BaseMenuActivity)this,BaseMenuActivity.DIARY_SER_FILENAME,meals.getClass());
        }catch(IOException e){
            /*
            Meals not Serialized yet, We have to create empty meals list
             */
            Log.e(TAG + "onCreate",e.getMessage());
            meals.add(new Meal("Breakfast"));
            meals.add(new Meal("Lunch"));
            meals.add(new Meal("Dinner"));
            meals.add(new Meal("Snacks"));
        }
        rvMeals = findViewById(R.id.rvMeals);
        rvMeals.setLayoutManager(new LinearLayoutManager(this));
        rvMeals.setAdapter(new MealAdapter(this,meals));
    }

    @Override
    public void loadMenuRes() {
        rootLayout = findViewById(R.id.layout_root);
        frameMenu = findViewById(R.id.frame_menu);
    }

    @Override
    public int getRootWidth() {
        return 3 * rootLayout.getWidth() / 4;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        super.onCreateOptionsMenu(menu);
        android.view.MenuItem item = menu.add(Menu.NONE,DiaryActivity.MENU_EDIT,Menu.NONE,getString(R.string.label_menu_diary_edit));
        item.setIcon(R.drawable.edit);
        item.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_IF_ROOM);

         item = menu.add(Menu.NONE,DiaryActivity.MENU_NUTRITION,Menu.NONE,getString(R.string.label_menu_diary_nutrition));
        item.setIcon(R.drawable.nutrition);
        item.setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onStop() {
        super.onStop();
        try{
            Log.d(TAG +"onStop"," Trying to serialize the curretn Diary");
            Serializer.getInstance().serialize((BaseMenuActivity)this,this.meals,BaseMenuActivity.DIARY_SER_FILENAME);
        }catch(IOException e){
            Log.e(TAG + "onStop",e.getMessage());
        }
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item){
        return super.onOptionsItemSelected(item);
    }



    @Override
    public void onFoodClick(Food food,int mealId) {
        Log.d(TAG + " onFoodClick",food.getName()+ " on the mealId: " + mealId);

       manager.beginTransaction()
                .setCustomAnimations(android.R.anim.slide_in_left,
                        android.R.anim.slide_out_right,
                        android.R.anim.slide_in_left,
                        android.R.anim.slide_out_right
                        )
                .replace(R.id.frame_food_detail_frag,FoodDetailFragment.newInstance(food.ID,mealId),DiaryActivity.FRAGMENT_FOOD_DETAIL)
                .addToBackStack(null)
                .commit();
    }


    @Override
    public void onFoodEdited(int foodId,int mealId,double newQuantityGrams) {
        Log.d(TAG + "onFoodEdited ","Diary activity delagating adapter to update a meal");
        double lastKcal = meals.get(mealId).getKcal();
        meals.get(mealId).updateFood(foodId,newQuantityGrams);
        fragBalance = (BalanceFragment)manager.findFragmentByTag(BalanceFragment.TAG_FRAG_BALANCE);
        fragBalance.addCalories((int)(meals.get(mealId).getKcal()-lastKcal));
        ((MealAdapter)rvMeals.getAdapter()).updateFood(foodId,mealId,newQuantityGrams);
    }

    @Override
    public void onAddFoodFragmentInit(int mealId) {
        Log.d(TAG + "onAddFoodFragmentInit","Opening Fragment for meal " + mealId);
        AddFoodDialogFragment fragment = AddFoodDialogFragment.newInstance(mealId);
        fragment.show(manager,FRAGMENT_ADD_FOOD);
    }

    @Override
    public void onFoodAdded(Food food, int mealId) {
        Log.d(TAG + "onFoodAdded","Adding food to the meal " + mealId);
        ApplicationClass.addFood(food);
        user.increaseActualKcal((int)food.getTotalKCal());
        fragBalance = (BalanceFragment)manager.findFragmentByTag(BalanceFragment.TAG_FRAG_BALANCE);
        fragBalance.addCalories((int)food.getTotalKCal());
       // meals.get(mealId).addFood(food);
        ((MealAdapter)rvMeals.getAdapter()).addFood(food,mealId);

    }
}