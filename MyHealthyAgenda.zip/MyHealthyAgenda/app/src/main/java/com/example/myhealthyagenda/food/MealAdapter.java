package com.example.myhealthyagenda.food;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myhealthyagenda.R;

import java.util.ArrayList;

public class MealAdapter extends RecyclerView.Adapter<MealAdapter.ViewHolder> {

    private ArrayList<Meal> meals;
    private ArrayList<FoodAdapter> foodAdapters;
    private Context context;
    private OnAddFoodFragmentInitListener mOnAddFoodFragmentInitListener;

    public MealAdapter(Context context,ArrayList<Meal> meals){
        this.meals = meals;
        this.context = context;
        this.foodAdapters = new ArrayList<>();
        try{
            this.mOnAddFoodFragmentInitListener = (OnAddFoodFragmentInitListener)context;
        }catch(ClassCastException e){
            Log.e("MealAdapter::<init>()","Could not cast toOnAddFoodFragmentInitListener!");
        }
    }
    @Override
    public MealAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int position){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_meal,parent,false);
        return new MealAdapter.ViewHolder(itemView);
    }
    @Override
    public void onBindViewHolder(MealAdapter.ViewHolder holder, int position){
        holder.itemView.setTag(position);
        holder.tvTitle.setText(meals.get(position).getName());
        holder.tvTotalKcal.setText(String.format("%4.2f",meals.get(position).getKcal()));
        if(position < foodAdapters.size())
            holder.rvFoods.setAdapter(foodAdapters.get(position));
        else{
            Log.d("DEBUG","Adding a new Food adapter to the position" + position);
            FoodAdapter mFoodAdapter = new FoodAdapter(context, meals.get(position).getFoods(),position);
            foodAdapters.add(mFoodAdapter);
            holder.rvFoods.setAdapter(mFoodAdapter);
        }
    }
    @Override
    public int getItemCount(){
        return meals.size();
    }

    public FoodAdapter getFoodAdapter(int foodAdapterId){
        return foodAdapters.get(foodAdapterId);
    }

    public void addFood(Food food, int mealId){
        this.meals.get(mealId).addFood(food);
        getFoodAdapter(mealId).addFood(food);

        notifyItemChanged(mealId);
    }
    public void updateFood(int foodId,int mealId,double newQuantityGrams){
        Log.d("MealAdapter::updateFood","Delegating a FoodAdapter to update a food internally. MealID: " + mealId);
        foodAdapters.get(mealId).updateSingleItem(foodId);
        notifyItemChanged(mealId);
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvTitle,tvTotalKcal;
        LinearLayout addFood;
        RecyclerView rvFoods;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvTotalKcal = itemView.findViewById(R.id.tvTotalKcal);
            addFood = itemView.findViewById(R.id.linearAddFood);
            rvFoods = itemView.findViewById(R.id.rvFoods);
            rvFoods.setLayoutManager(new LinearLayoutManager(context));
            rvFoods.setHasFixedSize(true);

            addFood.setOnClickListener(view->{
                   mOnAddFoodFragmentInitListener.onAddFoodFragmentInit((Integer)itemView.getTag());
            });
        }
    }

    public interface OnAddFoodFragmentInitListener{
        void onAddFoodFragmentInit(int mealId);
    }
}
