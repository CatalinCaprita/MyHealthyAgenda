package com.example.myhealthyagenda.food;

import java.time.LocalDate;
import java.util.Map;

public class DailyDiary {
    private Map<Integer,Meal> meals;
    private LocalDate logDate;

}
