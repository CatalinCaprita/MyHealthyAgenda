package com.example.myhealthyagenda.pages.diary.fragments;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.myhealthyagenda.ApplicationClass;
import com.example.myhealthyagenda.R;
import com.example.myhealthyagenda.food.Food;
import com.example.myhealthyagenda.food.Macronutrient;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.interfaces.datasets.IPieDataSet;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FoodDetailFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FoodDetailFragment extends Fragment  implements DialogEditFoodFragment.onFoodServingEditListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String FOOD_ID = "param1";
    private static final String MEAL_ID = "param2";
    private int foodID;
    private int mealId;
    private Food boundFood;
    private View mainView;
    private Activity host;
    private TextView tvFoodName,tvEditServings;
    private ProgressBar pbFromTotal;
    private boolean isInstantiated;
    PieChart pieChart;
    private ArrayList<String> names;
    private ArrayList<PieEntry>pieEntries;
    private static final int[] colors = {Color.BLUE,Color.GREEN,Color.RED};
    public static String [] namesMacro;

    /*
        Communicating with the dialog fragment
     */
    public static final int REQ_DIALOG_Q = 1;

    private OnFoodEditedListener onFoodEditedListener;
    public FoodDetailFragment() {
        // Required empty public constructor
    }

    public static FoodDetailFragment newInstance(int foodID, int mealId) {
        FoodDetailFragment fragment = new FoodDetailFragment();
        Bundle args = new Bundle();
        args.putInt(FOOD_ID, foodID);
        args.putInt(MEAL_ID,mealId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        this.host = (Activity)context;
        try{
            this.onFoodEditedListener = (FoodDetailFragment.OnFoodEditedListener)context;
        }catch(ClassCastException e){
            Log.e("ESCAPE",e.getLocalizedMessage());
        }
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            foodID = getArguments().getInt(FoodDetailFragment.FOOD_ID);
            boundFood = ApplicationClass.getFood(foodID);
            mealId = getArguments().getInt(FoodDetailFragment.MEAL_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mainView =  inflater.inflate(R.layout.fragment_food_detail, container, false);
        return mainView;
    }
    @RequiresApi(api = Build.VERSION_CODES.R)
    @SuppressLint("SetTextI18n")
    @Override
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        namesMacro = getActivity().getResources().getStringArray(R.array.macroNames);
        pieChart = (PieChart)mainView.findViewById(R.id.pie_chart_macros);
        pieEntries = new ArrayList<>(3);
        for(int i=0 ; i< 3; i++){
            pieEntries.add(new PieEntry(0f));
        }
        setChartInfo();
        tvFoodName = mainView.findViewById(R.id.tvFoodName);
        tvFoodName.setText(getString(R.string.info_food_name_producer,boundFood.getName(),boundFood.getSource()));
        tvEditServings = mainView.findViewById(R.id.tvEditServings);
        tvEditServings.setText(Double.toString(boundFood.getQuantityGrams()));

        tvEditServings.setOnClickListener(view->{
            DialogEditFoodFragment dialog = new DialogEditFoodFragment();
            dialog.setTargetFragment(FoodDetailFragment.this,FoodDetailFragment.REQ_DIALOG_Q);
            dialog.show(getFragmentManager(),"Dialog");
        });

        pbFromTotal = mainView.findViewById(R.id.pbFromTotal);
        pbFromTotal.setProgress((int)boundFood.getTotalKCal());
        pbFromTotal.setMax(2500);


    }
    @Override
    public void onFoodServingsEdit(double newQuantityGrams) {
        tvEditServings.setText(Double.toString(newQuantityGrams));
        /*
            Visually update food info, on the chart and in the fragment
         */
        onFoodEditedListener.onFoodEdited(boundFood.ID,mealId,newQuantityGrams);
        /*
            Propagate the changed food to the owner activity, so it is updated in the RecyclerView
         */

        setChartInfo();
        pieChart.getData().notifyDataChanged();
        pieChart.notifyDataSetChanged();
        pieChart.invalidate();


    }
    private void setChartInfo(){
        if(!isInstantiated) {
            pieChart.setHoleRadius(80f);
            pieChart.setHighlightPerTapEnabled(true);
            pieChart.setMinimumHeight(mainView.getHeight() / 2);
            pieChart.setExtraBottomOffset(-50);
            Description desc = new Description();
            desc.setText(getString(R.string.desc_macro_content));
            pieChart.setDescription(desc);
            pieChart.setDrawEntryLabels(false);
            pieChart.setCenterTextSize(28);
            isInstantiated = true;
        }
        pieChart.setCenterText(String.format("%4.2f \n cal",boundFood.getTotalKCal()));

        pieEntries.get(Macronutrient.CARB).setY((float)boundFood.getMacro(Macronutrient.CARB));
        pieEntries.get(Macronutrient.PROTEIN).setY((float)boundFood.getMacro(Macronutrient.PROTEIN));
        pieEntries.get(Macronutrient.FAT).setY((float)boundFood.getMacro(Macronutrient.FAT));

        PieDataSet dataSet = new PieDataSet(pieEntries,getString(R.string.desc_macro_content));
        dataSet.setSliceSpace(2f);
        dataSet.setDrawValues(false);
        dataSet.setColors(Color.BLUE,Color.GREEN,Color.RED);
        dataSet.setValueTextColor(R.color.colorAccentFront);

        Legend pieLegend = pieChart.getLegend();
        pieLegend.setEnabled(true);
        pieLegend.setVerticalAlignment(Legend.LegendVerticalAlignment.CENTER);
        pieLegend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        pieLegend.setOrientation(Legend.LegendOrientation.VERTICAL);
        pieLegend.setForm(Legend.LegendForm.CIRCLE);

        pieLegend.setTextSize(18f);
        pieLegend.setStackSpace(20f);
        pieLegend.setFormToTextSpace(5f);
        pieLegend.setTextColor(R.color.colorAccent);
        //setting custom labels
        final String[] labels = {
                getString(R.string.info_food_detail_pct_carb,boundFood.getMacro(Macronutrient.CARB),boundFood.getMacroPercent(Macronutrient.CARB)),
                getString(R.string.info_food_detail_pct_protein,boundFood.getMacro(Macronutrient.PROTEIN),boundFood.getMacroPercent(Macronutrient.PROTEIN)),
                getString(R.string.info_food_detail_pct_fat,boundFood.getMacro(Macronutrient.FAT),boundFood.getMacroPercent(Macronutrient.FAT)),
        };
        List<LegendEntry> entries= new ArrayList<>();
        for(int i=0 ; i < colors.length; i++){
            entries.add(new LegendEntry(labels[i], Legend.LegendForm.CIRCLE,12f,12f,null,colors[i]));
        }
        pieLegend.setCustom(entries);
        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(12);
        data.setValueTextColor(R.color.colorTextPrimary);
        pieChart.setData(data);

    }

    public interface OnFoodEditedListener{
        void onFoodEdited(int foodId,int mealId,double newQuantityGrams);
    }

}