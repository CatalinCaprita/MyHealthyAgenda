package com.example.myhealthyagenda.food;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;

public class Food implements Serializable {
    private static final long serialVersionUID = 10000000l;
    private final Macronutrient[] macros = new Macronutrient[3];
    private String name;
    private String source = "Source";
    private static transient int count;
    public final int ID = count++;
    private double quantityGrams;

    static{
        count = 0 ;
    }
    public  Food(){
    }

    /**
     * Constructor for a type of Food
     * @param name the name of the food
     * @param carbsGrams the amount of carbohydrates per 100 grams of food
     * @param proteinsGrams the amount of proteins per 100 grams of food
     * @param fatsGrams the amount of fats per 100 grams of food
     * @param quantityGrams the amount of food introduced
     */
    public Food(String name,double carbsGrams,double proteinsGrams,double fatsGrams,double quantityGrams){
        macros[Macronutrient.CARB] = new Macronutrient(carbsGrams / 100 * quantityGrams,Macronutrient.CARB);
        macros[Macronutrient.FAT] = new Macronutrient(fatsGrams / 100 * quantityGrams,Macronutrient.FAT);
        macros[Macronutrient.PROTEIN] = new Macronutrient(proteinsGrams / 100 * quantityGrams,Macronutrient.PROTEIN);
        this.quantityGrams = quantityGrams;
        this.name = name;

    }

    public double getQuantityGrams() {
        return quantityGrams;
    }


    public double getTotalKCal(){
        double totalKCal = 0;
        for(int i=0 ; i < macros.length; i++)
            totalKCal += macros[i].getKcal();
        return  totalKCal;
    }

    public double getMacro(int type) throws IndexOutOfBoundsException{
        switch (type){
            case Macronutrient.CARB:{ return macros[Macronutrient.CARB].getQuantity();}
            case Macronutrient.PROTEIN:{ return macros[Macronutrient.PROTEIN].getQuantity();}
            case Macronutrient.FAT:{ return macros[Macronutrient.FAT].getQuantity();}
            default:
                throw new IndexOutOfBoundsException();
        }
    }

    public double getMacroPercent(int type) throws IndexOutOfBoundsException{
        double q;
        switch (type){
            case Macronutrient.CARB:{ q = macros[Macronutrient.CARB].getKcal() ; break;}
            case Macronutrient.PROTEIN:{ q =  macros[Macronutrient.PROTEIN].getKcal();  break;}
            case Macronutrient.FAT:{ q = macros[Macronutrient.FAT].getKcal();  break;}
            default:
                throw new IndexOutOfBoundsException();
        }
        return q / getTotalKCal()  * 100 ;
    }

    public ArrayList<Double> getMacros(){
        ArrayList<Double> res = new ArrayList<>();
        res.add(macros[Macronutrient.CARB].getQuantity());
        res.add(macros[Macronutrient.PROTEIN].getQuantity());
        res.add(macros[Macronutrient.FAT].getQuantity());
        return res;
    }
    @Override
    public String toString(){
        String format = String.format("%s : %4.2f Carbohydrates, %4.2f Proteins, %4.2f fats",
                this.name,
                this.macros[Macronutrient.CARB].getQuantity(),
                this.macros[Macronutrient.PROTEIN].getQuantity(),
                this.macros[Macronutrient.FAT].getQuantity());
        return format;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setQuantity(double newQuantityGrams){
        for(int i=0 ; i < macros.length; i++){
            //Log.d("Food::setQuantity","Macro" + i +" : " + macros[i].getQuantity());
            macros[i].setQuantity(macros[i].getQuantity() * newQuantityGrams / this.quantityGrams);
            //Log.d("Food::setQuantity","Macro" + i +" : " + macros[i].getQuantity());
        }
        this.quantityGrams = newQuantityGrams;
    }
}
