package com.example.myhealthyagenda.user.util;

public class UserFileException extends  Exception {
    public UserFileException(String message){
        super(message);
    }
}
